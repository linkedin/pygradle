xref consistency
----------------

.. cpp:namespace:: xref_consistency

.. cpp:class:: item

code-role:      :code:`item`
any-role:       :any:`item`
cpp-any-role:   :cpp:any:`item`
cpp-expr-role:  :cpp:expr:`item`
cpp-texpr-role: :cpp:texpr:`item`
