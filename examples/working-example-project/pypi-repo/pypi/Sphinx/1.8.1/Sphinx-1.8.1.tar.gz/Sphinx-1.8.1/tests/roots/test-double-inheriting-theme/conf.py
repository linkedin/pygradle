# -*- coding: utf-8 -*-

templates_path = ['_templates']
master_doc = 'index'
html_theme = 'base_theme2'
html_theme_path = ['base_themes_dir']
exclude_patterns = ['_build']
