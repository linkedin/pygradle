=========================================
test-ext-autosectionlabel-prefix-document
=========================================


Introduce of Sphinx
===================

Installation
============

For Windows users
-----------------

For UNIX users
--------------

This one's got an apostrophe
----------------------------


References
==========

* :ref:`index:Introduce of Sphinx`
* :ref:`index:Installation`
* :ref:`index:For Windows users`
* :ref:`index:For UNIX users`
* :ref:`index:This one's got an apostrophe`
